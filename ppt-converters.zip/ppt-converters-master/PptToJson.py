import sys
from helpers import pptToJson
# Accessing command-line arguments
pdf_file_path = sys.argv[1]

# Using the PDF file path and other arguments within your script
print(f"PDF file path: {pdf_file_path}")
pptToJson(pdf_file_path)

